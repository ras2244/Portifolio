#pragma once
#include <iostream>

void process(char *str);

