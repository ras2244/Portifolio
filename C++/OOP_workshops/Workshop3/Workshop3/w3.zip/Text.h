#pragma once
#include <fstream>
#include <iostream>
#include <string>

using namespace std;

namespace w3{
  

  class Text{
    size_t count;
    string* goodTable;
  public:
    ~Text(){
      delete[] goodTable;
      goodTable = nullptr;
    }

    Text():count(0), goodTable(nullptr){}// default constructor needed for w3.cpp:21

    Text(char* f);
    Text& operator = (const Text& rhs);

    Text&& operator = (Text&& rhs);

    Text(const Text& rhs);

    Text(Text&& rhs);

    void dump();

    size_t size()const;

  };//text
} // namespace