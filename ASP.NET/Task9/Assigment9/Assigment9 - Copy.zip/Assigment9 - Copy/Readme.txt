﻿
BEFORE running this app for the first time...

Add your own design model classes,
in the DesignModelClasses.cs source code file.

Then, add DbSet<TEntity> properties in the 
IdentityModels.cs source code file.
